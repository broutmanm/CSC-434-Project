import sqlite3

db_locale = 'students.db'

connie = sqlite3.connect(db_locale)
c = connie.cursor()

c.execute("""
INSERT INTO contact_details (firstname, lastname, suburb) VALUES
('Kelsie', 'Schwager', 'candy_land'),
('Jen', 'Bartlett', 'candy_land'),
('Jenay', 'Bartlett', 'smarty_pants_town'),
('Mo', 'Jo', 'dog_lounge')

""")

connie.commit()
connie.close()
