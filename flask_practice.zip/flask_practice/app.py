from flask import Flask, render_template

app = Flask(__name__)

@app.route('/')
@app.route('/home')
def home_page():
    return render_template('home.html')

@app.route('/product')
def product_page():
    return render_template('our-product.html')

@app.route('/questions')
def questions_page():
    return render_template('questions.html')

@app.route('/add')
def add_student():
    return 'here is where we will add students'

if __name__ == '__main__':
    app.run()

